package com.ds.model;

public class Config {
	public final static String dburl
		= "jdbc:oracle:thin:@localhost:1521:xe";
	public final static String dbid = "hr";
	public final static String dbpw = "1234";
	
	
}
